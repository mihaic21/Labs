create view listAllGrades
as
	


select * from listAllGrades