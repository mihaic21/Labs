insert into Teachers values ('teacher1')
insert into Teachers values ('teacher2')
insert into Teachers values ('teacher3')

insert into Students values ('student1')
insert into Students values ('student2')
insert into Students values ('student3')

insert into Categories values ('category1')
insert into Categories values ('category2')
insert into Categories values ('category3')

insert into Questions values ('How was the course?', 1)
insert into Questions values ('Did the teacher yell?', 2)
insert into Questions values ('Would you recommend?', 3)

