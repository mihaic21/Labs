package UI;

import javax.swing.*;

/**
 * Created by mihai on 27.05.2014.
 */
public class EditForm {
    private JPanel rootPanel;
}
