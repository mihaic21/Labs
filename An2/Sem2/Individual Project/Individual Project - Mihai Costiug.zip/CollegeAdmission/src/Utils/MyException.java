package Utils;

/**
 * Created by mihai on 19.05.2014.
 */
public class MyException extends Exception {

    public MyException(String message){
        super(message);
    }

}
